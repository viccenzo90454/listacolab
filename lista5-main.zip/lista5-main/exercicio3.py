nomes=["dipirona" ,"Paracetamol" ,"Loratadina"]
precos=[12.50 ,9.90 ,18.75]
estoques=[20 ,15 ,8]

medicamentos = {
    "dipirona": {"preco": 12.50, "estoque": 20},
    "Paracetamol": {"preco": 9.90, "estoque": 15},
    "Loratadina": {"preco": 18.75, "estoque": 8}
}
nomes = ["dipirona", "Paracetamol", "Loratadina"]
precos = [12.50, 9.90, 18.75]
estoques = [20, 15, 8]

for i in range(len(nomes)):
    print(f"Medicamento: {nomes[i]} | Preço: R$ {precos[i]:.2f} | Estoque: {estoques[i]} un")
