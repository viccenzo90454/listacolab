tentativas = []
total_pontos = 0
convertidos = 0
errados = 0

print("Digite o resultado de cada uma das 10 tentativas:")
print("(0 = Errado, 1 = Cesta de 1pt, 2 = Cesta de 2pt, 3 = Cesta de 3pt)\n")


while len(tentativas) < 10:
    try:
        resultado = int(input(f"Resultado da tentativa {len(tentativas) + 1}: "))
    except ValueError:
        print("Entrada inválida! Digite apenas números inteiros.")
        continue

    if resultado not in [0, 1, 2, 3]:
        print("Valor inválido! Digite apenas 0, 1, 2 ou 3.")
        continue

    tentativas.append(resultado)
    total_pontos += resultado

    if resultado == 0:
        errados += 1
    else:
        convertidos += 1

    calculo_media = total_pontos / len(tentativas)
     

 
    
print("media de pontos por tentativa:", calculo_media)
print("\nResumo das tentativas:")
print(f"Total de pontos: {total_pontos}")
print(f"Tentativas convertidas: {convertidos}")
print(f"Tentativas erradas: {errados}")

 
  

      
    
        
            