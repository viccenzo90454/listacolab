
jogadores = ["Lucas", "Gabriel", "Rafael", "Pedro", "André"]
gols = [4, 7, 2, 7, 5]


def somar(lista):
    return sum(lista)

total_gols = somar(gols)
print(f"O total de gols é: {total_gols}")

media_gols = total_gols / len(gols)
print(f"A média de gols por jogador é: {media_gols:.1f}")#Media de gols


maior_gols = max(gols)
print(f"\nArtilharia do campeonato ({maior_gols} gols):")#maior gol.

# Exibe quem fez o maior número
for i in range(len(jogadores)):
    if gols[i] == maior_gols:
        print(f"- {jogadores[i]}")

    



